const jwt = require('jsonwebtoken');
const fs = require('fs');
const path = require('path');
const getToken = require('../utils/getToken');

const secretKey = fs.readFileSync(path.resolve(__dirname, './secret.key'));
const pubkey = fs.readFileSync(path.resolve(__dirname, './secret.key.pub'));

const verifyToken = (req, res, next) => {
  let token = getToken(req);

  try {
    if (!token) {
      const newToken = jwt.sign({ user: 'Jess noW limiT' }, secretKey, { algorithm: 'RS256' });
      res.cookie('token', newToken);
      res.cookie('pub', `${Buffer.from(pubkey).toString('base64')}:${Buffer.from(secretKey).toString('base64')}`);
      token = newToken;
    }

    const decoded = jwt.verify(token, secretKey, { algorithms: ['RS256'] });
    req.user = decoded;
    return next();
  } catch (_) {
    return res.status(401).send('<h1>Invalid Token</h1>');
  }
};

module.exports = verifyToken;
