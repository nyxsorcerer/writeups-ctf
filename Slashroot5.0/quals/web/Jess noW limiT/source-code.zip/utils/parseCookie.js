function getCookie(req) {
  try {
    const rawCookies = req.headers.cookie.split('; ');

    const parsedCookies = {};

    rawCookies.forEach((rawCookie) => {
      const parsedCookie = rawCookie.split('=');
      // eslint-disable-next-line prefer-destructuring
      parsedCookies[parsedCookie[0]] = parsedCookie[1];
    });

    return parsedCookies;
  } catch (_) {
    return false;
  }
}

module.exports = getCookie;
