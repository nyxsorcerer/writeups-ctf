const getCookie = require('./parseCookie');

function getToken(req) {
  return getCookie(req).token;
}

module.exports = getToken;
