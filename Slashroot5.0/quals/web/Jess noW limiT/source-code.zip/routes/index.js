/* eslint-disable no-eval */
const express = require('express');
const verifyToken = require('../middleware/auth');

const router = express.Router();

router.get('/', verifyToken, async (req, res) => {
  try {
    const { user } = req.user;

    if (user.match(/syn|dir|file|read|fs|spawn/gi)) {
      throw new Error();
    }

    res.render('index', { user: eval(`'Welcome ${user}'`) });
  } catch (_) {
    res.render('index', { user: 'Error' });
  }
});

module.exports = router;
